package com.satansminion.myhell.therockapp.data

import android.os.AsyncTask
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.beust.klaxon.JsonReader
import com.beust.klaxon.Klaxon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import java.io.StringReader
import java.net.URL
import java.util.Calendar

/**
 *
 * Created by Satans-Minion on 27/01/2019
 * Project: TheRockApp
 *
 */
private const val TAG = "Repository"

class Repository private constructor(private val songDao: SongDao) {

    fun insertSavedSong(savedSong: SavedSong) = runBlocking {
        GlobalScope.launch(Dispatchers.IO) {
            Log.d(TAG, "Got to Repository - ${Thread.currentThread().name}")
            songDao.insert(savedSong)
        }

    }

    //    fun getAllSavedSongs() = songDao.getAllSavedSongs()
    fun getAllSavedSongs(): LiveData<List<SavedSong>> {
        return songDao.getAllSavedSongs()
    }

//    Create a singleton of the Dao
    companion object {
        @Volatile
        private var instance: Repository? = null

        fun getInstance(songDao: SongDao) =
            instance ?: synchronized(this) {
                instance ?: Repository(songDao).also { instance = it }
            }
    }

    private var jsonDataUrlBase = ""
    var searchResults = MutableLiveData<ArrayList<Song>>()

    fun getJsonData() {
        Log.d(TAG, "getJsonData")
        val task = JsonAsyncTask()
        task.delegate = this
        task.execute(jsonDataUrlBase)
    }

    fun asyncFinished(result: ArrayList<Song>) {
        searchResults.value = result
    }

    init {
        jsonDataUrlBase =
            "https://radio-api.mediaworks.nz/radio-api/v2/station/therock/playedList?unique=true&fromUTC=${getDateFrom()}&toUTC=${getDateTo()}"
        Log.d(TAG, "URL: $jsonDataUrlBase")
    }

    private class JsonAsyncTask : AsyncTask<String, Void, ArrayList<Song>>() {
        var delegate: Repository? = null

        override fun doInBackground(vararg params: String?): ArrayList<Song> {

            val songArray = arrayListOf<Song>()
            Log.d(TAG, "fetchUrlData: Starting")
            try {
                Log.d(TAG, "fetchUrlData: Try - $params[0]")
                val entireJson = URL(params[0]).readText()

                val klax = Klaxon()
                JsonReader(StringReader(entireJson)).use { reader ->
                    reader.beginArray {
                        Log.d(TAG, "Beginning Loop")
                        while (reader.hasNext()) {
                            val song = klax.parse<Song>(reader)
                            songArray.add(song!!)
                        }
                    }
                }
                Log.d(TAG, "Array Size: ${songArray.size}")
            } catch (ex: Exception) {
                Log.e(TAG, "Error: ${ex.message}")
            }

            Log.d(TAG, "Song count: ${songArray.size}")
            return songArray
        }

        override fun onPostExecute(result: ArrayList<Song>) {
//            super.onPostExecute(result)
            delegate?.asyncFinished(result)
        }
    }

    private fun fetchUrlData(): ArrayList<Song> {
        val songArray = arrayListOf<Song>()
        Log.d(TAG, "fetchUrlData: Starting")
        try {
            Log.d(TAG, "fetchUrlData: Try - ${jsonDataUrlBase}")
            val entireJson = URL(jsonDataUrlBase).readText()

            val klax = Klaxon()
            JsonReader(StringReader(entireJson)).use { reader ->
                reader.beginArray {
                    Log.d(TAG, "Beginning Loop")
                    while (reader.hasNext()) {
                        val song = klax.parse<Song>(reader)
                        songArray.add(song!!)
                    }
                }
            }
            Log.d(TAG, "Array Size: ${songArray.size}")
        } catch (ex: Exception) {
            Log.e(TAG, "Error: ${ex.message}")
        }

        Log.d(TAG, "Song count: ${songArray.size}")
        return songArray
    }

    private fun getDateTo(): String {
        val e = System.currentTimeMillis() / 1000
        Log.d(TAG, "Time to (Milliseconds): $e")
        return e.toString()
    }

    private fun getDateFrom(): String {

        val c: Calendar = Calendar.getInstance()
        val now = c.timeInMillis

        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
//        val timePassed = now - c.timeInMillis
        Log.d(TAG, "Time from: ${c.timeInMillis}")
        return c.timeInMillis.toString()
    }
}