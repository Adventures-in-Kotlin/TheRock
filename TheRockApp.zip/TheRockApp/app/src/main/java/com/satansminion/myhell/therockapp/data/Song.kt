package com.satansminion.myhell.therockapp.data

/**
 *
 * Created by Satans-Minion on 27/01/2019
 * Project: TheRockApp
 *
 */
class Song(val title: String, val artist: String, val played_date: String, val played_time: String, val artwork: String)